document.getElementById('connectAll').addEventListener('click', async () => {
  const delay = parseInt(document.getElementById('delay').value) || 2000;
  const maxRequests = parseInt(document.getElementById('maxRequests').value) || 50;
  
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab.url.includes('linkedin.com')) {
    document.getElementById('status').textContent = 'Error: This is not a LinkedIn page';
    return;
  }
  
  document.getElementById('status').textContent = 'Working... Please keep this tab open';
  
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    args: [delay, maxRequests],
    func: (delay, maxRequests) => {
      const statusElement = document.createElement('div');
      statusElement.style.position = 'fixed';
      statusElement.style.bottom = '20px';
      statusElement.style.right = '20px';
      statusElement.style.backgroundColor = 'white';
      statusElement.style.padding = '10px';
      statusElement.style.border = '1px solid #ccc';
      statusElement.style.borderRadius = '5px';
      statusElement.style.zIndex = '9999';
      statusElement.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
      document.body.appendChild(statusElement);
      
      let count = 0;
      let skipped = 0;
      
      function processNextBatch() {
        const connectButtons = Array.from(document.querySelectorAll('button')).filter(btn => {
          const span = btn.querySelector('span');
          return span && span.textContent === 'Connect';
        });
        
        if (connectButtons.length === 0 || count >= maxRequests) {
          statusElement.textContent = `Done! Sent ${count} requests, skipped ${skipped}`;
          return;
        }
        
        const button = connectButtons[0];
        button.scrollIntoView({ behavior: 'smooth', block: 'center' });
        button.click();
        
        setTimeout(() => {
          const sendButtons = Array.from(document.querySelectorAll('button')).filter(btn => {
            const span = btn.querySelector('span');
            return span && span.textContent === 'Send';
          });
          
          if (sendButtons.length > 0) {
            sendButtons[0].click();
            count++;
            statusElement.textContent = `Sent ${count} requests (${skipped} skipped)...`;
          } else {
            skipped++;
          }
          
          setTimeout(processNextBatch, delay);
        }, 500);
      }
      
      processNextBatch();
    }
  });
});